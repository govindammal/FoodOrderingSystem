package com.example.quickfeast;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class creation  extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.creation1);
	    TextView t1=(TextView)findViewById(R.id.textView1);
	    t1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i1=new Intent(creation.this,mdisplay.class);
				startActivity(i1);
				
			}
		});
	  
	    

}}
