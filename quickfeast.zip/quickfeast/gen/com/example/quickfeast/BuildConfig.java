/** Automatically generated file. DO NOT MODIFY */
package com.example.quickfeast;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}