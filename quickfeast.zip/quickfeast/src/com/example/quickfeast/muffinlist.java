package com.example.quickfeast;

//import com.example.quickfeast.mdisplay;
//import com.example.quickfeast.usepass;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class muffinlist extends Activity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.muffin1);
Button b2=(Button)findViewById(R.id.button2);
Button b1=(Button)findViewById(R.id.button1);
      Bundle b = getIntent().getExtras();
      String[] resultArr = b.getStringArray("selectedItems");
      ListView lv = (ListView) findViewById(R.id.outputList);

      ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
              android.R.layout.simple_list_item_1, resultArr);
      lv.setAdapter(adapter); 
     	b1.setOnClickListener(new View.OnClickListener() {
            @Override
        	            
            public void onClick(View v) {

Intent intent =new Intent(muffinlist.this, muffin.class);
        	                 startActivity(intent);
  }
         });
      
        	    
}


}