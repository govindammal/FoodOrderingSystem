package com.example.quickfeast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

//import com.example.quickfeast.usepass.pass_value_to_db;

//import android.R.menu;
import android.annotation.SuppressLint;
//import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
//import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
//import android.widget.TextView;
import android.widget.Toast;

public class usepass extends MainActivity {
	EditText ed1, ed2;
	Button b1;
	ProgressDialog dialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.userpassword);
		//TextView textView = (TextView) findViewById(R.id.textView1);
		/*Typeface font = Typeface.createFromAsset(getAssets(),
				"fontawesome-webfont.ttf");
		// Set the typeface
		textView.setTypeface(font);*/
		ed1 = (EditText) findViewById(R.id.editText1);
		ed2 = (EditText) findViewById(R.id.editText2);
		b1 = (Button) findViewById(R.id.button1);
		b1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				String EmailId = ed1.getText().toString();
				String Password = ed2.getText().toString();

				try {
					EmailId = URLEncoder.encode(EmailId, "UTF-8");
					Password = URLEncoder.encode(Password, "UTF-8");

					String url = "http://10.100.9.194/reg.php?&emailid="
							+ EmailId.trim() + "&password=" + Password;
					System.out.println(url);
					pass_value_to_db get = new pass_value_to_db();
					get.execute(new String[] { url });

				} catch (UnsupportedEncodingException e) {

					e.printStackTrace();

				}
			}
		});

	}

	public class pass_value_to_db extends AsyncTask<String, Void, String> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {
			dialog = new ProgressDialog(usepass.this);
			dialog.setTitle("Processing...");
			dialog.setMessage("Please wait.");
			dialog.setCancelable(false);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... urls) {
			String result = "";
			for (String url : urls) {
				InputStream is = null;
				try {

					HttpClient httpclient = new DefaultHttpClient();
					HttpPost httppost = new HttpPost(url);
					HttpResponse response = httpclient.execute(httppost);
					int status = response.getStatusLine().getStatusCode();

					Log.d("KG", "status=" + status);

					if (status == 200) {
						HttpEntity entity = response.getEntity();
						is = entity.getContent();
						BufferedReader reader = new BufferedReader(
								new InputStreamReader(is, "iso-8859-1"), 8);
						String line = "";
						while ((line = reader.readLine()) != null) {
							result += line;
						}
						is.close();

						Log.v("KG", result);

					}
				} catch (Exception ex) {
					Log.e("Error", ex.toString());
				}
			}
			return result;
		}

		@SuppressLint("NewApi")
		protected void onPostExecute(String result) {
			Log.v("KG", "output=" + result);
			result = result.trim(); //

			if (result.equals("false")) {

				Toast.makeText(getApplicationContext(), "Please try again",
						Toast.LENGTH_LONG).show();
			} else {
				System.out.println(result);
				// Intent i = new Intent(usepass.this, menu.class);
				// startActivity(i);
				Toast.makeText(getApplicationContext(), "successful",
						Toast.LENGTH_LONG).show();
				Intent i = new Intent(usepass.this, mdisplay.class);
				startActivity(i);

			}
			if (dialog != null)
				dialog.dismiss();

		}
	}

}
