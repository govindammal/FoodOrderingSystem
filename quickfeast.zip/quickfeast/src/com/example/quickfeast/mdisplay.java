package com.example.quickfeast;

//import android.R.string;
import android.app.Activity;
import android.content.Intent;
//import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
//import android.widget.ArrayAdapter;
//import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class mdisplay extends Activity {

	ListView list1;
	String[] itemname = { ("ECLAIR"), ("MELLOW"), ("MUFFIN"), 

	};

	Integer[] imgid = { R.drawable.i1, R.drawable.i2, R.drawable.i3,
			
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu1);

		inn adapter = new inn(this, itemname, imgid);
		list1 = (ListView) findViewById(R.id.listView1);
		//ArrayAdapter<String> adapter1 =new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,itemname);
		list1.setAdapter(adapter);
		
		list1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				
				String Slecteditem = itemname[position];
				
				Toast.makeText(getApplicationContext(), Slecteditem,
						Toast.LENGTH_SHORT).show();
				switch (position) {
				case 0:
					Intent i = new Intent(mdisplay.this, eclair.class);
					startActivity(i);
					break;
				case 1:
					Intent i1 = new Intent(mdisplay.this, mellow.class);
					startActivity(i1);
					break;
				case 2:
					Intent i2 = new Intent(mdisplay.this, muffin.class);
					startActivity(i2);
					break;
				
				}
			}
		});
	}

}


